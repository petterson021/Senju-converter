import {ChangeDetectionStrategy, Component, signal, HostListener, ElementRef, inject, PLATFORM_ID} from '@angular/core';
import {CommonModule, isPlatformBrowser} from '@angular/common';
import {FormsModule, ReactiveFormsModule, FormControl, Validators, AbstractControl, ValidationErrors} from '@angular/forms';
import {MatIconModule} from '@angular/material/icon';

type Step = 'idle' | 'detecting' | 'converting' | 'completed' | 'error';
type Platform = 'youtube' | 'spotify' | 'soundcloud' | 'deezer' | 'apple' | 'tidal' | 'amazon' | 'snaptube' | 'unknown' | null;

interface HistoryItem {
  id: number;
  url: string;
  format: string;
  quality: string;
  date: Date;
  platform: Platform;
}

interface Ripple {
  x: number;
  y: number;
  id: number;
}

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-root',
  imports: [CommonModule, FormsModule, ReactiveFormsModule, MatIconModule],
  templateUrl: './app.html',
  styleUrl: './app.css',
  host: {
    'class': 'block min-h-screen'
  }
})
export class App {
  private el = inject(ElementRef);
  private platformId = inject(PLATFORM_ID);
  urlControl = new FormControl('', {
    validators: [Validators.required, this.musicUrlValidator()],
    updateOn: 'change'
  });
  quality = signal<string>('320kbps');
  format = signal<string>('mp3');
  status = signal<Step>('idle');
  progress = signal<number>(0);
  detectedPlatform = signal<Platform>(null);
  errorMessage = signal<string | null>(null);
  isMobile = signal<boolean>(false);
  isPlaylist = signal<boolean>(false);
  showDownloadOptions = signal<boolean>(false);
  ripples = signal<Ripple[]>([]);
  history = signal<HistoryItem[]>([]);
  private rippleId = 0;

  private platformPatterns = {
    youtube: /(youtube\.com|youtu\.be)/i,
    spotify: /spotify\.com/i,
    soundcloud: /soundcloud\.com/i,
    deezer: /deezer\.com/i,
    apple: /music\.apple\.com/i,
    tidal: /tidal\.com/i,
    amazon: /amazon\.(com|com\.br|co\.uk)\/music/i,
    snaptube: /snaptube/i
  };

  platforms = [
    { id: 'youtube', name: 'YouTube', logo: 'https://cdn.simpleicons.org/youtube/FF0000', color: '#FF0000' },
    { id: 'spotify', name: 'Spotify', logo: 'https://cdn.simpleicons.org/spotify/1DB954', color: '#1DB954' },
    { id: 'soundcloud', name: 'SoundCloud', logo: 'https://cdn.simpleicons.org/soundcloud/FF3300', color: '#FF3300' },
    { id: 'snaptube', name: 'Snaptube', logo: 'data:image/svg+xml;base64,PHN2ZyB2aWV3Qm94PSIwIDAgMjQgMjQiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PHBhdGggZD0iTTEyIDBDNS4zNzMgMCAwIDUuMzczIDAgMTJzNS4zNzMgMTIgMTIgMTIgMTItNS4zNzMgMTItMTJTMTguNjI3IDAgMTIgMHptMCAxOGwtNC00aDNWOGgydjRoM2wtNCA0eiIgZmlsbD0iI0ZGQ0MwMCIvPjwvc3ZnPg==', color: '#FFCC00' },
    { id: 'apple', name: 'Apple Music', logo: 'https://cdn.simpleicons.org/applemusic/FA243C', color: '#FA243C' },
    { id: 'deezer', name: 'Deezer', logo: 'https://cdn.simpleicons.org/deezer/EF5466', color: '#EF5466' },
    { id: 'tidal', name: 'Tidal', logo: 'https://cdn.simpleicons.org/tidal/FFFFFF', color: '#FFFFFF' },
    { id: 'amazon', name: 'Amazon Music', logo: 'https://cdn.simpleicons.org/amazonmusic/00A8E1', color: '#00A8E1' }
  ];

  private musicUrlValidator() {
    return (control: AbstractControl): ValidationErrors | null => {
      const value = control.value;
      if (!value) return null;

      try {
        new URL(value);
      } catch (e) {
        return { invalidUrl: 'Formato de link inválido. Certifique-se de incluir http:// ou https://' };
      }

      const isSupported = Object.values(this.platformPatterns).some(pattern => pattern.test(value));
      if (!isSupported) {
        return { unsupportedPlatform: 'Este link não pertence a uma plataforma suportada.' };
      }

      return null;
    };
  }

  get validationError(): string | null {
    if (this.urlControl.pristine || !this.urlControl.invalid) return null;
    const errors = this.urlControl.errors;
    if (errors?.['required']) return 'O link é obrigatório.';
    if (errors?.['invalidUrl']) return errors['invalidUrl'];
    if (errors?.['unsupportedPlatform']) return errors['unsupportedPlatform'];
    return 'Link inválido.';
  }

  constructor() {
    if (isPlatformBrowser(this.platformId)) {
      this.checkDevice();
      this.loadHistory();
    }
    // Platform and Playlist detection logic
    this.urlControl.valueChanges.subscribe(value => {
      if (!value) {
        this.detectedPlatform.set(null);
        this.isPlaylist.set(false);
        return;
      }
      
      const val = value.toLowerCase();
      let detected: Platform = 'unknown';
      
      for (const [platform, pattern] of Object.entries(this.platformPatterns)) {
        if (pattern.test(val)) {
          detected = platform as Platform;
          break;
        }
      }
      
      this.detectedPlatform.set(detected);
      this.isPlaylist.set(val.includes('playlist') || val.includes('/sets/') || val.includes('album'));
    });
  }

  @HostListener('window:resize')
  checkDevice() {
    if (isPlatformBrowser(this.platformId)) {
      this.isMobile.set(window.innerWidth < 768);
    }
  }

  @HostListener('mousedown', ['$event'])
  @HostListener('touchstart', ['$event'])
  onInteract(event: MouseEvent | TouchEvent) {
    const x = 'clientX' in event ? event.clientX : event.touches[0].clientX;
    const y = 'clientY' in event ? event.clientY : event.touches[0].clientY;
    
    const id = this.rippleId++;
    this.ripples.update(prev => [...prev, { x, y, id }]);
    
    setTimeout(() => {
      this.ripples.update(prev => prev.filter(r => r.id !== id));
    }, 1000);
  }

  async convert() {
    if (this.urlControl.invalid) return;

    this.status.set('detecting');
    this.errorMessage.set(null);
    this.progress.set(0);

    try {
      // Simulate detection phase
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      this.status.set('converting');
      
      // Simulate conversion progress
      const interval = setInterval(() => {
        const next = this.progress() + Math.random() * 15;
        if (next >= 100) {
          this.progress.set(100);
          clearInterval(interval);
          this.addToHistory();
          this.status.set('completed');
        } else {
          this.progress.set(next);
        }
      }, 400);

    } catch {
      this.status.set('error');
      this.errorMessage.set('Falha na conversão. Verifique o link e tente novamente.');
    }
  }

  reset() {
    this.status.set('idle');
    this.urlControl.reset();
    this.progress.set(0);
    this.detectedPlatform.set(null);
    this.showDownloadOptions.set(false);
  }

  joinDiscord() {
    window.open('https://discord.gg/RrZJBZDgyk', '_blank');
  }

  toggleDownload() {
    this.showDownloadOptions.update(v => !v);
  }

  downloadFormat(format: string, quality: string) {
    this.format.set(format);
    this.quality.set(quality);
    this.showDownloadOptions.set(false);
    // Real download logic would go here
    const blob = new Blob(['Download content'], { type: 'text/plain' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `senju-audio-${Date.now()}.${format}`;
    a.click();
    window.URL.revokeObjectURL(url);
  }

  download() {
    this.downloadFormat(this.format(), this.quality());
  }

  private loadHistory() {
    const saved = localStorage.getItem('senju_history');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        this.history.set(parsed.map((item: any) => ({
          ...item,
          date: new Date(item.date)
        })));
      } catch (e) {
        console.error('Error loading history', e);
      }
    }
  }

  private addToHistory() {
    const newItem: HistoryItem = {
      id: Date.now(),
      url: this.urlControl.value || '',
      format: this.format(),
      quality: this.quality(),
      date: new Date(),
      platform: this.detectedPlatform()
    };
    
    this.history.update(h => [newItem, ...h].slice(0, 10)); // Keep last 10
    if (isPlatformBrowser(this.platformId)) {
      localStorage.setItem('senju_history', JSON.stringify(this.history()));
    }
  }

  clearHistory() {
    this.history.set([]);
    if (isPlatformBrowser(this.platformId)) {
      localStorage.removeItem('senju_history');
    }
  }

  getPlatformIcon(id: Platform): string {
    const p = this.platforms.find(plat => plat.id === id);
    return p ? p.logo : '';
  }
}
